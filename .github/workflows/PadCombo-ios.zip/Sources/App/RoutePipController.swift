import AVKit
import SwiftUI
import UIKit

/// Shows the solved route in a Picture-in-Picture window that floats above the
/// game. iOS gives third-party apps exactly one way to float above another app,
/// and this is it: the PiP video-call surface, reused as a drawing board.
final class RoutePipController: NSObject, AVPictureInPictureControllerDelegate {
    static let shared = RoutePipController()

    private var controller: AVPictureInPictureController?
    private var host: UIHostingController<RoutePipView>?

    func show(from sourceView: UIView, board: PDBoard, route: PDRoute) {
        guard AVPictureInPictureController.isPictureInPictureSupported() else { return }

        let hosting = UIHostingController(rootView: RoutePipView(board: board, route: route))
        hosting.view.backgroundColor = .black

        let pipViewController = AVPictureInPictureVideoCallViewController()
        pipViewController.preferredContentSize = CGSize(width: 340, height: 210)
        pipViewController.addChild(hosting)
        hosting.view.frame = pipViewController.view.bounds
        hosting.view.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        pipViewController.view.addSubview(hosting.view)
        hosting.didMove(toParent: pipViewController)

        let source = AVPictureInPictureController.ContentSource(
            activeVideoCallSourceView: sourceView,
            contentViewController: pipViewController)

        let pipController = AVPictureInPictureController(contentSource: source)
        pipController.delegate = self
        pipController.canStartPictureInPictureAutomaticallyFromInline = true

        controller = pipController
        host = hosting
        pipController.startPictureInPicture()
    }

    func update(board: PDBoard, route: PDRoute) {
        host?.rootView = RoutePipView(board: board, route: route)
    }

    func stop() {
        controller?.stopPictureInPicture()
        controller = nil
        host = nil
    }
}

struct RoutePipView: View {
    let board: PDBoard
    let route: PDRoute

    private let headerHeight: CGFloat = 20

    var body: some View {
        GeometryReader { geometry in
            let cellWidth = geometry.size.width / CGFloat(PDBoard.cols)
            let cellHeight = (geometry.size.height - headerHeight) / CGFloat(PDBoard.rows)
            let orb = min(cellWidth, cellHeight) * 0.82

            ZStack(alignment: .topLeading) {
                Color.black

                ForEach(0..<PDBoard.cellCount, id: \.self) { index in
                    Circle()
                        .fill(Self.color(for: board.cells[index]))
                        .frame(width: orb, height: orb)
                        .position(x: (CGFloat(PDBoard.col(of: index)) + 0.5) * cellWidth,
                                  y: (CGFloat(PDBoard.row(of: index)) + 0.5) * cellHeight + headerHeight)
                }

                Path { path in
                    for (step, index) in route.path.enumerated() {
                        let point = CGPoint(
                            x: (CGFloat(PDBoard.col(of: index)) + 0.5) * cellWidth,
                            y: (CGFloat(PDBoard.row(of: index)) + 0.5) * cellHeight + headerHeight)
                        if step == 0 {
                            path.move(to: point)
                        } else {
                            path.addLine(to: point)
                        }
                    }
                }
                .stroke(Color.white.opacity(0.95), lineWidth: 2.5)

                if let start = route.path.first {
                    Circle()
                        .stroke(Color.white, lineWidth: 2)
                        .frame(width: orb, height: orb)
                        .position(x: (CGFloat(PDBoard.col(of: start)) + 0.5) * cellWidth,
                                  y: (CGFloat(PDBoard.row(of: start)) + 0.5) * cellHeight + headerHeight)
                }

                Text("\(route.combos) combo · \(route.path.count) 格")
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundColor(.white)
                    .padding(.horizontal, 6)
                    .frame(height: headerHeight)
            }
        }
    }

    static func color(for orb: Int) -> Color {
        switch orb {
        case Orb.fire: return Color(red: 0.90, green: 0.25, blue: 0.22)
        case Orb.water: return Color(red: 0.25, green: 0.55, blue: 0.95)
        case Orb.wood: return Color(red: 0.38, green: 0.80, blue: 0.38)
        case Orb.light: return Color(red: 0.98, green: 0.86, blue: 0.28)
        case Orb.dark: return Color(red: 0.62, green: 0.32, blue: 0.78)
        case Orb.heart: return Color(red: 0.96, green: 0.50, blue: 0.63)
        default: return Color(white: 0.35)
        }
    }
}
