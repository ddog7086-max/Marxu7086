import SwiftUI

struct ContentView: View {
    @ObservedObject var state: AppState

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    statusCard
                    boardCard
                    calibrationCard
                    buttons
                    notes
                }
                .padding()
            }
            .navigationTitle("PadCombo")
            .navigationBarTitleDisplayMode(.inline)
            .background(PipAnchor { view in state.anchor = view }.frame(width: 1, height: 1))
        }
    }

    private var statusCard: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(state.isPipRunning ? "画中画运行中" : "未开启画中画")
                .font(.headline)
            if let capturedAt = state.capturedAt {
                Text("最后一次识屏：\(capturedAt.formatted(date: .omitted, time: .standard))")
                    .font(.footnote)
                    .foregroundColor(.secondary)
            } else {
                Text("还没有收到画面。先启动屏幕录制广播（见下方说明）。")
                    .font(.footnote)
                    .foregroundColor(.secondary)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding()
        .background(Color(.secondarySystemBackground), in: RoundedRectangle(cornerRadius: 12))
    }

    private var boardCard: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text("识别到的盘面").font(.headline)
                Spacer()
                Text("\(state.route.combos) combo")
                    .font(.subheadline.weight(.semibold))
                    .foregroundColor(.blue)
            }
            if let board = state.board {
                RoutePipView(board: board, route: state.route)
                    .frame(height: 190)
                    .clipShape(RoundedRectangle(cornerRadius: 10))
            } else {
                RoundedRectangle(cornerRadius: 10)
                    .fill(Color(.secondarySystemBackground))
                    .frame(height: 190)
                    .overlay(Text("等待画面").foregroundColor(.secondary))
            }
        }
    }

    private var calibrationCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("盘面区域校准").font(.headline)
            Text("用四个滑杆把盘面框到 6x5 的珠阵上，无需精确到像素。")
                .font(.footnote)
                .foregroundColor(.secondary)

            slider("左", value: binding(\.x), range: 0...0.6)
            slider("上", value: binding(\.y), range: 0...0.8)
            slider("宽", value: binding(\.width), range: 0.2...1.0)
            slider("高", value: binding(\.height), range: 0.1...0.6)
        }
        .padding()
        .background(Color(.secondarySystemBackground), in: RoundedRectangle(cornerRadius: 12))
    }

    private var buttons: some View {
        VStack(spacing: 10) {
            Button {
                state.isPipRunning ? state.stopPip() : state.startPip()
            } label: {
                Text(state.isPipRunning ? "关闭画中画" : "开启画中画路线")
                    .frame(maxWidth: .infinity)
            }
            .buttonStyle(.borderedProminent)
            .disabled(state.board == nil)

            Button {
                state.recompute()
            } label: {
                Text("重新计算路线").frame(maxWidth: .infinity)
            }
            .buttonStyle(.bordered)
            .disabled(state.board == nil)
        }
    }

    private var notes: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("使用顺序").font(.headline)
            Text("""
            1. 打开 P&D，进到要转珠的那一回合。
            2. 下拉控制中心，长按「屏幕录制」，选择 PadCombo 后开始录制。
            3. 回到本 App 点「开启画中画路线」，画中画小窗会浮在游戏上。
            4. 每回合盘面变化后，小窗会在约 1 秒内更新路线，照着划即可。
            """)
            .font(.footnote)

            Text("注意").font(.headline).padding(.top, 6)
            Text("""
            · 识别靠的是颜色，不同主题/机型可能需要微调（见 README 的调参点）。
            · 天空掉落是随机的，路线只计算你这一步能确定的 combo。
            · 这是外部辅助工具，P&D 的用户条款并不欢迎这类做法，账号风险由你自己承担。
            """)
            .font(.footnote)
            .foregroundColor(.secondary)
        }
    }

    private func slider(_ title: String, value: Binding<Double>, range: ClosedRange<Double>) -> some View {
        HStack(spacing: 10) {
            Text(title).frame(width: 24, alignment: .leading)
            Slider(value: value, in: range, onEditingChanged: { editing in
                if !editing { state.commitRect() }
            })
            Text(String(format: "%.3f", value.wrappedValue))
                .font(.caption.monospacedDigit())
                .foregroundColor(.secondary)
                .frame(width: 48, alignment: .trailing)
        }
    }

    private func binding(_ keyPath: WritableKeyPath<PDBoardRect, Double>) -> Binding<Double> {
        Binding(
            get: { state.rect[keyPath: keyPath] },
            set: { newValue in
                state.rect[keyPath: keyPath] = newValue
                state.commitRect()
            })
    }
}
