import AVFoundation
import SwiftUI

@main
struct PadComboApp: App {
    @StateObject private var state = AppState()

    var body: some Scene {
        WindowGroup {
            ContentView(state: state)
                .onAppear { state.start() }
        }
    }
}
