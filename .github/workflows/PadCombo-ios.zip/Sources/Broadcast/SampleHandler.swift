import CoreImage
import CoreMedia
import ReplayKit

/// Broadcast upload extension: iOS hands us screen frames only while the user
/// runs a broadcast from Control Center. We sample roughly once a second,
/// recognise the board, and drop the result into the shared container.
final class SampleHandler: RPBroadcastSampleHandler {
    private let context = CIContext()
    private var lastAnalysis = Date.distantPast
    private let minimumInterval: TimeInterval = 1.0

    override func broadcastStarted(withSetupInfo setupInfo: [String: NSObject]?) {}

    override func broadcastPaused() {}

    override func broadcastResumed() {}

    override func broadcastFinished() {}

    override func processSampleBuffer(_ sampleBuffer: CMSampleBuffer,
                                      with sampleBufferType: RPSampleBufferType) {
        guard sampleBufferType == .video else { return }
        guard Date().timeIntervalSince(lastAnalysis) >= minimumInterval else { return }
        guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }
        lastAnalysis = Date()

        let width = CVPixelBufferGetWidth(pixelBuffer)
        guard width > 0 else { return }

        // Recognition only needs the 6x5 cell centres, so work on a downscaled copy.
        let scale = min(1.0, 900.0 / Double(width))
        let image = CIImage(cvPixelBuffer: pixelBuffer)
            .transformed(by: CGAffineTransform(scaleX: scale, y: scale))
        guard let cgImage = context.createCGImage(image, from: image.extent) else { return }

        let rect = PDShared.loadRect()
        guard let board = OrbRecognizer.classify(cgImage, rect: rect) else { return }
        PDShared.save(board: board)
        // Free certificates have no App Group, so the UDP path is the real one.
        PDNet.send(board.cells)
    }
}
