import Foundation

/// Board rectangle, normalised to the screen (0...1, origin top-left).
/// This is the only thing you calibrate: where the 6x5 board sits on your phone.
struct PDBoardRect: Codable, Equatable {
    var x: Double
    var y: Double
    var width: Double
    var height: Double

    static let fallback = PDBoardRect(x: 0.07, y: 0.615, width: 0.86, height: 0.235)
}

/// The app and the broadcast extension are separate processes, so everything
/// travels through the App Group container plus a Darwin notification.
enum PDShared {
    /// Must be identical in PadCombo.entitlements, BroadcastExt.entitlements
    /// and the bundle identifiers in project.yml.
    static let appGroupID = "group.com.example.padcombo"

    static let notificationName = "com.example.padcombo.boardUpdated"

    private static let snapshotName = "latest_board.json"
    private static let rectName = "board_rect.json"

    struct Snapshot: Codable {
        var cells: [Int]
        var capturedAt: Double
    }

    private static var container: URL? {
        FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: appGroupID)
    }

    // MARK: board snapshot

    static func save(board: PDBoard) {
        guard let url = container?.appendingPathComponent(snapshotName) else { return }
        let snapshot = Snapshot(cells: board.cells, capturedAt: Date().timeIntervalSince1970)
        guard let data = try? JSONEncoder().encode(snapshot) else { return }
        try? data.write(to: url, options: .atomic)
        notify()
    }

    static func loadBoard() -> (board: PDBoard, capturedAt: Date)? {
        guard let url = container?.appendingPathComponent(snapshotName),
              let data = try? Data(contentsOf: url),
              let snapshot = try? JSONDecoder().decode(Snapshot.self, from: data) else { return nil }
        return (PDBoard(cells: snapshot.cells), Date(timeIntervalSince1970: snapshot.capturedAt))
    }

    // MARK: calibration

    static func save(rect: PDBoardRect) {
        guard let url = container?.appendingPathComponent(rectName) else { return }
        if let data = try? JSONEncoder().encode(rect) {
            try? data.write(to: url, options: .atomic)
        }
    }

    static func loadRect() -> PDBoardRect {
        guard let url = container?.appendingPathComponent(rectName),
              let data = try? Data(contentsOf: url),
              let rect = try? JSONDecoder().decode(PDBoardRect.self, from: data) else {
            return .fallback
        }
        return rect
    }

    // MARK: cross-process wake-up

    private static var handlers: [() -> Void] = []

    static func observe(_ handler: @escaping () -> Void) {
        handlers.append(handler)
        guard handlers.count == 1 else { return }
        CFNotificationCenterAddObserver(
            CFNotificationCenterGetDarwinNotifyCenter(),
            nil,
            { _, _, _, _, _ in
                PDShared.handlers.forEach { $0() }
            },
            notificationName as CFString,
            nil,
            .deliverImmediately)
    }

    static func notify() {
        CFNotificationCenterPostNotification(
            CFNotificationCenterGetDarwinNotifyCenter(),
            CFNotificationName(rawValue: notificationName as CFString),
            nil, nil, true)
    }
}
