import Foundation
import Network

/// Entitlement-free channel between the broadcast extension and the main app.
///
/// App Groups need a paid developer account. Everyone else only has a free
/// certificate, where the shared container simply does not exist. In that case
/// the extension pushes a one-datagram snapshot to the app over UDP on
/// localhost, which needs no entitlements at all.
enum PDNet {
    static let port: UInt16 = 51999

    /// Extension side: fire and forget. A fresh connection per datagram keeps it
    /// stateless, and the app only needs the latest board anyway.
    static func send(_ cells: [Int]) {
        guard cells.count == PDBoard.cellCount,
              let data = try? JSONEncoder().encode(cells),
              let port = NWEndpoint.Port(rawValue: PDNet.port) else { return }
        let connection = NWConnection(host: "127.0.0.1", port: port, using: .udp)
        connection.start(queue: .global(qos: .utility))
        connection.send(content: data, completion: .contentProcessed { _ in
            connection.cancel()
        })
    }

    /// App side: listens while the app is alive (PiP keeps it alive).
    final class Receiver {
        private var listener: NWListener?
        private var handler: (([Int]) -> Void)?

        func start(handler: @escaping ([Int]) -> Void) {
            self.handler = handler
            guard listener == nil, let port = NWEndpoint.Port(rawValue: PDNet.port) else { return }

            let parameters = NWParameters.udp
            parameters.allowLocalEndpointReuse = true
            guard let listener = try? NWListener(using: parameters, on: port) else { return }

            self.listener = listener
            listener.newConnectionHandler = { [weak self] connection in
                connection.start(queue: .global(qos: .utility))
                self?.receive(on: connection)
            }
            listener.start(queue: .global(qos: .utility))
        }

        func stop() {
            listener?.cancel()
            listener = nil
        }

        private func receive(on connection: NWConnection) {
            connection.receiveMessage { [weak self] data, _, _, _ in
                if let data, let cells = try? JSONDecoder().decode([Int].self, from: data),
                   cells.count == PDBoard.cellCount {
                    self?.handler?(cells)
                }
                connection.cancel()
            }
        }
    }
}
