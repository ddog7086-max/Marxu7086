import Foundation

/// Orb colour identifiers. `empty` is only used by the simulator, never by the recognizer.
enum Orb {
    static let fire = 0
    static let water = 1
    static let wood = 2
    static let light = 3
    static let dark = 4
    static let heart = 5
    static let empty = -1
    static let colorCount = 6
}

/// 6 columns x 5 rows. `cells` is row-major: index = row * cols + col, row 0 is the top row.
struct PDBoard: Equatable {
    static let cols = 6
    static let rows = 5
    static let cellCount = cols * rows

    var cells: [Int]

    init(cells: [Int]) {
        precondition(cells.count == PDBoard.cellCount, "board must hold 30 cells")
        self.cells = cells
    }

    init(randomUsing generator: inout SplitMix64) {
        var cells = [Int]()
        cells.reserveCapacity(PDBoard.cellCount)
        for _ in 0..<PDBoard.cellCount {
            cells.append(Int.random(in: 0..<Orb.colorCount, using: &generator))
        }
        self.cells = cells
    }

    static func index(row: Int, col: Int) -> Int { row * cols + col }
    static func row(of index: Int) -> Int { index / cols }
    static func col(of index: Int) -> Int { index % cols }

    func cell(_ row: Int, _ col: Int) -> Int {
        cells[PDBoard.index(row: row, col: col)]
    }

    /// Net effect of one P&D drag: every orb on the path shifts one cell backwards,
    /// and the orb you picked up ends up on the last cell of the path.
    func dragged(along path: [Int]) -> PDBoard {
        guard path.count > 1 else { return self }
        let values = path.map { cells[$0] }
        var board = self
        for i in 0..<(path.count - 1) {
            board.cells[path[i]] = values[i + 1]
        }
        board.cells[path[path.count - 1]] = values[0]
        return board
    }

    /// All maximal horizontal / vertical runs of three or more identical orbs.
    func runs() -> [[Int]] {
        var found: [[Int]] = []

        for row in 0..<PDBoard.rows {
            var col = 0
            while col < PDBoard.cols {
                let value = cell(row, col)
                let start = col
                while col < PDBoard.cols, cell(row, col) == value { col += 1 }
                if value != Orb.empty, col - start >= 3 {
                    found.append((start..<col).map { PDBoard.index(row: row, col: $0) })
                }
            }
        }

        for col in 0..<PDBoard.cols {
            var row = 0
            while row < PDBoard.rows {
                let value = cell(row, col)
                let start = row
                while row < PDBoard.rows, cell(row, col) == value { row += 1 }
                if value != Orb.empty, row - start >= 3 {
                    found.append((start..<row).map { PDBoard.index(row: $0, col: col) })
                }
            }
        }

        return found
    }

    /// Clears matches, drops the remainder, and repeats. Returns the combo count.
    /// Skyfall is intentionally ignored: it is random, so predicting it is pointless.
    mutating func resolveCombos() -> Int {
        var combos = 0
        for _ in 0..<64 {
            let matched = runs()
            if matched.isEmpty { break }
            combos += matched.count
            for run in matched {
                for index in run { cells[index] = Orb.empty }
            }
            for col in 0..<PDBoard.cols {
                var survivors = [Int]()
                survivors.reserveCapacity(PDBoard.rows)
                for row in 0..<PDBoard.rows where cell(row, col) != Orb.empty {
                    survivors.append(cell(row, col))
                }
                let padding = PDBoard.rows - survivors.count
                for row in 0..<PDBoard.rows {
                    cells[PDBoard.index(row: row, col: col)] = row < padding ? Orb.empty : survivors[row - padding]
                }
            }
        }
        return combos
    }

    /// Cheap heuristic: how many cells already sit in a pair.
    var nearScore: Int {
        var score = 0
        for row in 0..<PDBoard.rows {
            var col = 0
            while col < PDBoard.cols {
                let value = cell(row, col)
                let start = col
                while col < PDBoard.cols, cell(row, col) == value { col += 1 }
                if value != Orb.empty, col - start == 2 { score += 1 }
            }
        }
        for col in 0..<PDBoard.cols {
            var row = 0
            while row < PDBoard.rows {
                let value = cell(row, col)
                let start = row
                while row < PDBoard.rows, cell(row, col) == value { row += 1 }
                if value != Orb.empty, row - start == 2 { score += 1 }
            }
        }
        return score
    }
}
