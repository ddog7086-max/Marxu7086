import CoreGraphics
import Foundation

/// Turns a screen image plus a board rectangle into 30 orb colours.
/// Recognition is the weakest link in the whole app: the reference colours below
/// are tuned for the classic six orbs and will need adjusting per theme / device.
enum OrbRecognizer {
    struct Reference {
        let color: Int
        let r: Double
        let g: Double
        let b: Double
    }

    /// Sampled from the middle of each orb type (0...1 RGB).
    static let references: [Reference] = [
        Reference(color: Orb.fire, r: 0.86, g: 0.22, b: 0.18),
        Reference(color: Orb.water, r: 0.22, g: 0.50, b: 0.92),
        Reference(color: Orb.wood, r: 0.35, g: 0.75, b: 0.35),
        Reference(color: Orb.light, r: 0.98, g: 0.85, b: 0.25),
        Reference(color: Orb.dark, r: 0.58, g: 0.28, b: 0.72),
        Reference(color: Orb.heart, r: 0.95, g: 0.45, b: 0.60)
    ]

    static func classify(_ image: CGImage, rect: PDBoardRect) -> PDBoard? {
        guard let pixels = rgbaPixels(of: image) else { return nil }
        let width = image.width
        let height = image.height

        var cells = [Int](repeating: Orb.empty, count: PDBoard.cellCount)

        for row in 0..<PDBoard.rows {
            for col in 0..<PDBoard.cols {
                let fx = rect.x + rect.width * (Double(col) + 0.5) / Double(PDBoard.cols)
                let fy = rect.y + rect.height * (Double(row) + 0.5) / Double(PDBoard.rows)
                let px = Int(fx * Double(width))
                let py = Int(fy * Double(height))
                guard px >= 3, px < width - 3, py >= 3, py < height - 3 else { continue }

                var r = 0.0, g = 0.0, b = 0.0, samples = 0.0
                for dy in -2...2 {
                    for dx in -2...2 {
                        let offset = ((py + dy) * width + (px + dx)) * 4
                        r += Double(pixels[offset])
                        g += Double(pixels[offset + 1])
                        b += Double(pixels[offset + 2])
                        samples += 1
                    }
                }
                r /= samples * 255.0
                g /= samples * 255.0
                b /= samples * 255.0

                cells[PDBoard.index(row: row, col: col)] = nearestColor(r: r, g: g, b: b)
            }
        }

        return PDBoard(cells: cells)
    }

    private static func nearestColor(r: Double, g: Double, b: Double) -> Int {
        var best = Orb.empty
        var bestDistance = Double.greatestFiniteMagnitude
        for reference in references {
            // Green is weighted slightly higher: heart and fire differ mostly there.
            let distance = (r - reference.r) * (r - reference.r)
                + 1.4 * (g - reference.g) * (g - reference.g)
                + (b - reference.b) * (b - reference.b)
            if distance < bestDistance {
                bestDistance = distance
                best = reference.color
            }
        }
        // Too far from anything we know: poison / nuisance / empty cell.
        return bestDistance > 1.6 ? Orb.empty : best
    }

    /// RGBA8, top-left origin.
    private static func rgbaPixels(of image: CGImage) -> [UInt8]? {
        let width = image.width
        let height = image.height
        var pixels = [UInt8](repeating: 0, count: width * height * 4)
        let colorSpace = CGColorSpaceCreateDeviceRGB()
        let bitmapInfo = CGImageAlphaInfo.premultipliedLast.rawValue

        let drawn: Bool = pixels.withUnsafeMutableBytes { raw -> Bool in
            guard let base = raw.baseAddress,
                  let context = CGContext(
                    data: base,
                    width: width,
                    height: height,
                    bitsPerComponent: 8,
                    bytesPerRow: width * 4,
                    space: colorSpace,
                    bitmapInfo: bitmapInfo) else { return false }
            // CGContext is bottom-left origin; flip so row 0 is the top of the image.
            context.translateBy(x: 0, y: CGFloat(height))
            context.scaleBy(x: 1, y: -1)
            context.draw(image, in: CGRect(x: 0, y: 0, width: width, height: height))
            return true
        }

        return drawn ? pixels : nil
    }
}
