import Foundation

/// Deterministic, fast RNG (SplitMix64). Deterministic matters: the same board
/// must always produce the same route, otherwise the overlay flickers between
/// candidates every frame.
struct SplitMix64: RandomNumberGenerator {
    private var state: UInt64

    init(seed: UInt64 = 0x9E37_79B9_7F4A_7C15) {
        state = seed
    }

    mutating func next() -> UInt64 {
        state &+= 0x9E37_79B9_7F4A_7C15
        var z = state
        z = (z ^ (z >> 30)) &* 0xBF58_476D_1CE4_E5B9
        z = (z ^ (z >> 27)) &* 0x94D0_49BB_1331_11EB
        return z ^ (z >> 31)
    }

    /// Uniform double in [0, 1).
    mutating func nextUnit() -> Double {
        Double(next() >> 11) * (1.0 / 9_007_199_254_740_992.0)
    }
}

struct PDRoute {
    var path: [Int]
    var combos: Int

    static let empty = PDRoute(path: [], combos: 0)
}

/// Simulated-annealing search over complete drag paths.
/// Verified against the Python reference in Tools/ (average ~6.6 combos on random boards).
enum PDSolver {
    private static let neighbours: [(Int, Int)] = [(-1, 0), (1, 0), (0, -1), (0, 1)]

    static func solve(
        _ board: PDBoard,
        maxLen: Int = 24,
        budgetPerRestart: Int = 1400,
        restarts: Int = 7,
        seed: UInt64 = 0x5DEE_CE66_D000_0001
    ) -> PDRoute {
        var rng = SplitMix64(seed: seed)

        var bestPath = [Int]()
        var bestScore = -Double.greatestFiniteMagnitude
        var bestCombos = 0

        // Seed the search from a handful of random drags, including short ones:
        // short paths often score better because of the length penalty.
        for _ in 0..<12 {
            let start = Int.random(in: 0..<PDBoard.cellCount, using: &rng)
            let length = Int.random(in: 8...maxLen, using: &rng)
            let candidate = randomPath(from: start, length: length, maxLen: maxLen, rng: &rng)
            let (score, combos) = evaluate(board, candidate)
            if score > bestScore {
                bestScore = score
                bestPath = candidate
                bestCombos = combos
            }
        }

        for _ in 0..<restarts {
            var currentPath = bestPath
            var currentScore = bestScore
            var temperature = 2.5

            for _ in 0..<budgetPerRestart {
                var candidate = currentPath

                if rng.nextUnit() < 0.6 {
                    // Re-route the tail from a random cell.
                    let cut = candidate.count > 1 ? Int.random(in: 1..<candidate.count, using: &rng) : 1
                    let head = Array(candidate.prefix(cut))
                    let room = maxLen - head.count
                    guard room >= 1 else { continue }
                    let extra = Int.random(in: 1...room, using: &rng)
                    let tail = randomPath(from: head[head.count - 1], length: extra, maxLen: maxLen, rng: &rng)
                    candidate = head + Array(tail.dropFirst())
                } else {
                    // Wiggle a single step.
                    guard candidate.count >= 2 else { continue }
                    let i = Int.random(in: 1..<candidate.count, using: &rng)
                    let options = neighbourIndices(of: candidate[i - 1])
                    guard !options.isEmpty else { continue }
                    candidate[i] = options[Int.random(in: 0..<options.count, using: &rng)]
                    if let broken = candidate.indices.dropFirst().first(where: {
                        !areAdjacent(candidate[$0 - 1], candidate[$0])
                    }) {
                        candidate = Array(candidate.prefix(broken))
                    }
                }

                guard candidate.count >= 2 else { continue }
                let (score, combos) = evaluate(board, candidate)
                let delta = score - currentScore
                if delta >= 0 || rng.nextUnit() < exp(delta / max(temperature, 1e-6)) {
                    currentPath = candidate
                    currentScore = score
                    if score > bestScore {
                        bestScore = score
                        bestPath = candidate
                        bestCombos = combos
                    }
                }

                temperature *= 0.9965
                if temperature < 0.05 { temperature = 2.5 }
            }
        }

        return PDRoute(path: bestPath, combos: bestCombos)
    }

    static func evaluate(_ board: PDBoard, _ path: [Int]) -> (score: Double, combos: Int) {
        var after = board.dragged(along: path)
        let combos = after.resolveCombos()
        // Combo count dominates; path length is only a tie-breaker, because every
        // extra cell costs the player time inside the 4-5 second window.
        return (Double(combos) * 10.0 - 0.35 * Double(path.count), combos)
    }

    static func randomPath(from start: Int, length: Int, maxLen: Int, rng: inout SplitMix64) -> [Int] {
        var path = [start]
        var previous = -1
        var last = start
        let target = min(length, maxLen)

        while path.count < target {
            let options = neighbourIndices(of: last).filter { $0 != previous }
            guard !options.isEmpty else { break }
            let next = options[Int.random(in: 0..<options.count, using: &rng)]
            path.append(next)
            previous = last
            last = next
        }
        return path
    }

    private static func neighbourIndices(of index: Int) -> [Int] {
        let row = PDBoard.row(of: index)
        let col = PDBoard.col(of: index)
        var options = [Int]()
        for (dRow, dCol) in neighbours {
            let nextRow = row + dRow
            let nextCol = col + dCol
            guard nextRow >= 0, nextRow < PDBoard.rows, nextCol >= 0, nextCol < PDBoard.cols else { continue }
            options.append(PDBoard.index(row: nextRow, col: nextCol))
        }
        return options
    }

    private static func areAdjacent(_ a: Int, _ b: Int) -> Bool {
        abs(PDBoard.row(of: a) - PDBoard.row(of: b)) + abs(PDBoard.col(of: a) - PDBoard.col(of: b)) == 1
    }
}
