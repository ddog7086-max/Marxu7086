# PadCombo（iOS 转珠路线助手）

给《Puzzle & Dragons》/《龙族拼图》用的 iOS 版「看盘 → 给路线」工具。
它做的是 PuzzCombo 那件事的**只读版**：读屏幕、算一条多 combo 的拖动路线，用画中画小窗浮在游戏上，你自己照着划。

**重要：这份代码写得完整，但从未在真机上编译过。** 开发环境里没有 macOS/Xcode，我无法编译、无法签名、无法验证。第一次编译大概率会碰到 1~3 个小错（拼写、API 签名），把报错贴给我就能改。

---

## 它怎么工作

```
┌────────────────────────── iPhone ──────────────────────────┐
│  P&D 游戏                                                  │
│      ↑ 手指照着划                                          │
│  画中画小窗（路线 + 盘面缩略图）  ← App 主进程一直活着      │
│      ↑ Darwin 通知 + App Group 文件                        │
│  屏幕录制广播扩展（每秒抓 1 帧）                            │
│      ↓                                                     │
│  识别 6×5 珠色 → 求解器算路线（约 6~7 combo，<0.2s）        │
└────────────────────────────────────────────────────────────┘
```

- `Sources/Shared/PDCore.swift` —— 盘面模型。核心机制：一次拖动的净效果是**路径上的珠整体后移一格，起手那颗落到终点**；消珠按行列 3 连、连锁下落重算，combo 数 = 清除的组数（含连锁）。天空掉落是随机的，故意不计入预测。
- `Sources/Shared/PDSolver.swift` —— 模拟退火搜整条路径（长度上限 24 格，约等于 5 秒手速）。评分 = combo ×10 − 0.35×路径长度。
- `Sources/Shared/OrbRecognizer.swift` —— 按盘面矩形切 6×5 格心，5×5 像素取均值，最近邻比 6 个参考色。
- `Sources/Shared/PDShared.swift` —— App Group 文件 + Darwin 通知，跨进程传盘面和校准参数。
- `Sources/Broadcast/SampleHandler.swift` —— ReplayKit 广播扩展，每秒 1 帧。
- `Sources/App/*` —— SwiftUI 界面、校准滑杆、画中画控制器（`AVPictureInPictureVideoCallViewController`，这是 iOS 上第三方 App 唯一能浮在别的 App 之上的形态）。

## 算法是验证过的

`Tools/` 里有 Python 参考实现（与 Swift 逻辑 1:1），已跑通：

```bash
cd Tools
python verify.py      # 机制 + 一致性 + 压力测试
python pad_sa.py      # 质量基准：平均 6.6 combo，约 0.57s/盘（Python，Swift 会快数倍）
```

覆盖：两格拖动=交换、路径整段后移、非路径格不变、4 连消除、重力压实、多组同时消=多 combo、求解结果可复现、路径始终相邻。

---

## 怎么装到 iPhone（两条路，任选）

### 路线 A：你有（或能借到）一台 Mac —— 最省事

1. 装 Xcode（App Store），再装 XcodeGen：`brew install xcodegen`
2. 在 `puzzcombo-ios/` 目录执行 `xcodegen generate`，打开生成的 `PadCombo.xcodeproj`
3. 改三处标识，把 `com.example` 换成你自己的（建议 `com.<你的英文名>`）：
   - `project.yml` 里两个 `PRODUCT_BUNDLE_IDENTIFIER`
   - 两个 `.entitlements` 里的 `group.com.example.padcombo`
   - `Sources/Shared/PDShared.swift` 里的 `appGroupID`
4. Xcode → Signing & Capabilities → Team 选你的 Apple ID，两个 target 都要选
5. 手机连上 Mac，Run。首次装完要去「设置 → 通用 → VPN与设备管理」信任开发者

### 路线 B：没有 Mac —— 云编译 + Windows 自签

1. 把整个 `puzzcombo-ios/` 推到你的 GitHub 仓库
2. 仓库 Actions 页手动跑 `build-ipa`（工作流已附，用 GitHub 的 macOS 机器编译，不需要你出 Mac）
3. 下载产物 `PadCombo.ipa`
4. Windows 装 [Sideloadly](https://sideloadly.io/) + iTunes，手机连电脑，用它 + 你的 Apple ID 签名安装
5. 免费账号证书 **7 天过期**，到期重签一次（Sideloadly 一键重签）

> App Group 是一个坎：免费 Apple ID 不一定能开这个能力（它会决定 App 和录屏扩展能不能共享数据）。
> 若安装后 App 里一直显示「还没有收到画面」，先怀疑这里 —— 那就要 $99/年的开发者账号，或者改用付费开发者签名。
> 代码里跨进程通道只集中在 `PDShared.swift`，换传输方式（比如改成写共享 Keychain）只需改这一个文件。

---

## 用法

1. 打开 P&D，进到要转珠的那一回合
2. 下拉控制中心 → 长按「屏幕录制」→ 选 **PadCombo** → 开始录制
3. 打开本 App，点「开启画中画路线」，小窗浮起（拖到不挡盘面的位置）
4. 每回合盘面一变，约 1 秒后小窗更新路线，从白圈起点照着小窗的线划

**校准**：如果识别出来的珠位置错位，用 App 里四个滑杆（左/上/宽/高）把框对到 6×5 珠阵，滑杆松手即保存。

## 已知限制

- **识别是最大变数**。参考色在 `OrbRecognizer.references` 里，心珠（粉）和火珠（红）最容易混，靠绿色通道加权区分；换主题/机型可能要重调这 6 个值。
- 画中画只有 ~340×210 的可视尺寸，路线要放大看，不能像安卓那样铺满整屏。
- 求解不预测天空掉落，实际 combo 通常比显示的多。
- 拖到 24 格以上会超出 5 秒手速，那部分路线意义不大。
- 每回合都要你亲手开一次屏幕录制广播（iOS 不允许 App 自己偷看别的 App，这是系统红线，绕不过）。

## 风险

这是外部辅助工具，P&D 的用户条款不欢迎这类做法，账号风险自担。它不读游戏内存、不注入、不代替你划，只做「看画面 + 画路线」，比自动代打低一档，但仍然是辅助工具。

把它当练习器用，收益反而更稳：它告诉你一条 7 combo 的路线长什么样，你照着划几遍，手感就上来了。
