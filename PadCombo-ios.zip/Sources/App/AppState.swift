import AVFoundation
import SwiftUI
import UIKit

@MainActor
final class AppState: ObservableObject {
    @Published var board: PDBoard?
    @Published var route: PDRoute = .empty
    @Published var capturedAt: Date?
    @Published var rect: PDBoardRect
    @Published var isPipRunning = false
    @Published var indexPath: [Int] = []

    weak var anchor: UIView?

    private var started = false
    private var lastCells: [Int]?

    init() {
        rect = PDShared.loadRect()
    }

    func start() {
        guard !started else { return }
        started = true
        // Keeping the audio session alive is what lets the app survive in the
        // background while the game is in front, which the PiP window needs.
        let session = AVAudioSession.sharedInstance()
        try? session.setCategory(.playback, mode: .moviePlayback, options: [.mixWithOthers])
        try? session.setActive(true, options: [])

        PDShared.observe { [weak self] in
            Task { @MainActor in self?.reload() }
        }
        reload()
    }

    func reload() {
        guard let snapshot = PDShared.loadBoard() else { return }
        board = snapshot.board
        capturedAt = snapshot.capturedAt
        guard snapshot.board.cells != lastCells else { return }
        lastCells = snapshot.board.cells
        recompute()
    }

    func recompute() {
        guard let board else { return }
        Task.detached(priority: .userInitiated) { [weak self] in
            let route = PDSolver.solve(board)
            await MainActor.run {
                guard let self else { return }
                self.route = route
                if self.isPipRunning {
                    RoutePipController.shared.update(board: board, route: route)
                }
            }
        }
    }

    func commitRect() {
        rect.width = min(max(rect.width, 0.05), 1.0)
        rect.height = min(max(rect.height, 0.05), 1.0)
        rect.x = min(max(rect.x, 0.0), 1.0 - rect.width)
        rect.y = min(max(rect.y, 0.0), 1.0 - rect.height)
        PDShared.save(rect: rect)
    }

    func startPip() {
        guard let anchor, let board else { return }
        RoutePipController.shared.show(from: anchor, board: board, route: route)
        isPipRunning = true
    }

    func stopPip() {
        RoutePipController.shared.stop()
        isPipRunning = false
    }
}

/// Invisible view used as the PiP source anchor.
struct PipAnchor: UIViewRepresentable {
    let onResolve: (UIView) -> Void

    func makeUIView(context: Context) -> UIView {
        let view = UIView(frame: .zero)
        view.isUserInteractionEnabled = false
        view.backgroundColor = .clear
        DispatchQueue.main.async { onResolve(view) }
        return view
    }

    func updateUIView(_ uiView: UIView, context: Context) {}
}
